﻿<#
    .SYNOPSIS
        Downloads an item from the media library in Sitecore PowerShell Extensions via web service calls.

   .NOTES
        v1.0 - 20150512
#>

function Receive-MediaItem {
    [CmdletBinding()]
    param(
        [Parameter(ParameterSetName='Session')]
        [ValidateNotNull()]
        [pscustomobject[]]$Session,

        [Parameter(ParameterSetName='Uri')]
        [string]$ConnectionUri,

        [Parameter(ParameterSetName='Uri')]
        [string]$SessionId,

        [Parameter(ParameterSetName='Uri')]
        [string]$Username,

        [Parameter(ParameterSetName='Uri')]
        [string]$Password,

        [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Path,
        
        [Parameter(Position=1, Mandatory=$true)]
        [Alias("RemotePath")]
		[ValidateNotNullOrEmpty()]
        [String]$Destination,

        [Parameter(Position=2)]
        [String]$Database = "master",

        [Parameter(Position=3)]
        [String]$Language = "en"
    )

    process {

        foreach($s in $Session) {

            if($PSCmdlet.ParameterSetName -eq "Session") {
                $ConnectionUri = $s.ConnectionUri
                $Username = $s.Username
                $Password = $s.Password
                $SessionId = $s.SessionId
            }

            Write-Verbose -Message "Connecting to web service."
            
            if(!$ConnectionUri.EndsWith(".asmx")) {
                $ConnectionUri = "$($ConnectionUri.TrimEnd('/'))/sitecore%20modules/PowerShell/Services/RemoteAutomation.asmx"
            }

            $proxy = New-WebServiceProxy -Uri $ConnectionUri
            if(-not $proxy) { return $null }

            Write-Verbose -Message "Downloading file content."
            [byte[]]$response = $proxy.DownloadFile($Username, $Password, $Path, $Database, $Language)
	
            if($response -and $response.Length -gt 0) {
                if(-not(Test-Path $Destination))
                {
                    New-Item -ItemType File -Path $Destination
                }

                Write-Verbose -Message "Writing file content."
                [System.IO.File]::WriteAllBytes((Convert-Path -Path $Destination), $response)

                Write-Verbose -Message "Download complete."
            } else {
                Write-Verbose -Message "Download failed. No content returned from the web service."
            }
        }
    }
}

Set-Alias -Name "Download-SitecoreFile" -Value "Receive-MediaItem" -Description "SPE"