﻿<#
    .SYNOPSIS
        Uploads an item to the media library in Sitecore PowerShell Extensions via web service calls.

   .NOTES
        v1.0 - 20150512
#>

function Send-MediaItem {
    [CmdletBinding()]
    param(
        [Parameter(ParameterSetName='Session')]
        [ValidateNotNull()]
        [pscustomobject]$Session,

        [Parameter(ParameterSetName='Uri')]
        [string]$ConnectionUri,

        [Parameter(ParameterSetName='Uri')]
        [string]$SessionId,

        [Parameter(ParameterSetName='Uri')]
        [string]$Username,

        [Parameter(ParameterSetName='Uri')]
        [string]$Password,

        [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true)]
        [ValidateNotNullOrEmpty()]
        [string]$Path,
        
        [Parameter(Position=1, Mandatory=$true)]
        [Alias("RemotePath")]
		[ValidateNotNullOrEmpty()]
        [String]$Destination,

        [Parameter(Position=2)]
        [String]$Database = "master",

        [Parameter(Position=3)]
        [String]$Language = "en"
    )

    process {

        foreach($s in $Session) {

            if($PSCmdlet.ParameterSetName -eq "Session") {
                $ConnectionUri = $s.ConnectionUri
                $Username = $s.Username
                $Password = $s.Password
                $SessionId = $s.SessionId
            }

            Write-Verbose -Message "Connecting to web service."
            
            if(!$ConnectionUri.EndsWith(".asmx")) {
                $ConnectionUri = "$($ConnectionUri.TrimEnd('/'))/sitecore%20modules/PowerShell/Services/RemoteAutomation.asmx"
            }

            $proxy = New-WebServiceProxy -Uri $ConnectionUri
            if(-not $proxy) { return $null }
	
            Write-Verbose -Message "Reading file content."
            [byte[]]$bytes = [System.IO.File]::ReadAllBytes($Path)

            if($bytes -and $bytes.Length -gt 0) {

                Write-Verbose -Message "Uploading file content."
                $proxy.UploadFile($Username, $Password, $Destination, $bytes, $Database, $Language) | Out-Null

                Write-Verbose -Message "Upload complete."
            } else {
                Write-Verbose -Message "Upload failed. No content to send to the web service."
            }
        }
    }
}

Set-Alias -Name "Upload-SitecoreFile" -Value "Send-MediaItem" -Description "SPE"