<#
    .SYNOPSIS
        Creates a new script session in Sitecore PowerShell Extensions via web service calls.

   .NOTES
        v1.0 - 20150503 
#>

function New-ScriptSession {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Username = $null,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string]$Password = $null,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [string[]]$ConnectionUri = $null 
    )

    process {

        foreach($uri in $ConnectionUri) {

            $script = {
                [Cognifide.PowerShell.Core.Host.ScriptSessionManager]::NewSession([Cognifide.PowerShell.Core.Settings.ApplicationNames]::RemoteAutomation, $false);
            }
            
            if(!$uri.EndsWith(".asmx")) {
                $uri = "$($uri.TrimEnd('/'))/sitecore%20modules/PowerShell/Services/RemoteAutomation.asmx"
            }

            $proxy = New-WebServiceProxy -Uri $uri
            if(-not $proxy) { return $null }

            $response = $proxy.ExecuteScriptBlock2($Username, $Password, $script.ToString(), $null, $SessionId)
            $session = ConvertFrom-CliXml -InputObject $response
    
            $sessionId = [guid]::Empty

            if([guid]::TryParse($session.ID, [ref] $sessionId)) {
                [PSCustomObject]@{
                    [string]"Username" = $Username
                    [string]"Password" = $Password
                    [string]"ConnectionUri" = $uri
                    [string]"SessionId" = $SessionId
                }
            } else {
                Write-Error -Message "There was a problem creating a new script session."
            }
        }
    }
}