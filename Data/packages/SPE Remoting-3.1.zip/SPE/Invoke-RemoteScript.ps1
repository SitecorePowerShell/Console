<#
    .SYNOPSIS
        Run scripts in Sitecore PowerShell Extensions via web service calls.

   .NOTES
        v1.0 - 20150503 
#>


function Invoke-RemoteScript {
    [CmdletBinding()]
    param(
        
        [Parameter(ParameterSetName='InProcess')]
        [Parameter(ParameterSetName='Session')]
        [Parameter(ParameterSetName='Uri')]
        [scriptblock]$ScriptBlock,

        [Parameter(ParameterSetName='Session')]
        [ValidateNotNull()]
        [pscustomobject]$Session,

        [Parameter(ParameterSetName='Uri')]
        [string]$ConnectionUri,

        [Parameter(ParameterSetName='Uri')]
        [string]$SessionId,

        [Parameter(ParameterSetName='Uri')]
        [string]$Username,

        [Parameter(ParameterSetName='Uri')]
        [string]$Password,

        [hashtable]$ArgumentList
    )

    if($PSCmdlet.ParameterSetName -eq "InProcess") {
        $ScriptBlock.Invoke()
    } else {
        if($PSCmdlet.ParameterSetName -eq "Session") {
            $ConnectionUri = $Session.ConnectionUri
            $Username = $Session.Username
            $Password = $Session.Password
            $SessionId = $Session.SessionId
        }
        
        if(!$ConnectionUri.EndsWith(".asmx")) {
            $ConnectionUri = "$($ConnectionUri.TrimEnd('/'))/sitecore%20modules/PowerShell/Services/RemoteAutomation.asmx"
        }

        $proxy = New-WebServiceProxy -Uri $ConnectionUri
        if(-not $proxy) { return $null }

        if($ArgumentList) {
            $parameters = ConvertTo-CliXml -InputObject $ArgumentList
        }
        $response = $proxy.ExecuteScriptBlock2($Username, $Password, $ScriptBlock.ToString(), $parameters, $SessionId)
        ConvertFrom-CliXml -InputObject $response
    }
}