﻿<#
    .SYNOPSIS
        Uploads an item to the media library in Sitecore PowerShell Extensions via web service calls.

   .EXAMPLE
        The following uploads all of the images in a directory to the specified path in the media library in the master db.
        
        $session = New-ScriptSession -Username admin -Password b -ConnectionUri http://remotesitecore
        Get-ChildItem -Path C:\Images | Send-MediaItem -Session $session -Destination "/sitecore/media library/Images/"

    .EXAMPLE
        The following uploads a single image with a new name to the specified path in the media library in the master db.

        $session = New-ScriptSession -Username admin -Password b -ConnectionUri http://remotesitecore
        Send-MediaItem -Session $session -Path C:\Images\banner.jpg -Destination "/sitecore/media library/Images/banner.jpg"
#>

function Send-MediaItem {
    [CmdletBinding()]
    param(
        [Parameter(ParameterSetName='Session')]
        [ValidateNotNull()]
        [pscustomobject]$Session,

        [Parameter(ParameterSetName='Uri')]
        [string]$ConnectionUri,

        [Parameter(ParameterSetName='Uri')]
        [string]$SessionId,

        [Parameter(ParameterSetName='Uri')]
        [string]$Username,

        [Parameter(ParameterSetName='Uri')]
        [string]$Password,

        [Parameter(ParameterSetName='Uri')]
        [System.Management.Automation.PSCredential]
        $Credential,

        [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$true, ValueFromPipelineByPropertyName=$true)]
        [Alias("FullName")]
        [ValidateNotNullOrEmpty()]
        [string]$Path,
        
        [Parameter(Position=1, Mandatory=$true)]
        [Alias("RemotePath")]
		[ValidateNotNullOrEmpty()]
        [String]$Destination,

        [Parameter(Position=2)]
        [String]$Database = "master",

        [Parameter(Position=3)]
        [String]$Language = "en"
    )

    process {

        foreach($s in $Session) {

            if($PSCmdlet.ParameterSetName -eq "Session") {
                $ConnectionUri = $s.ConnectionUri
                $Username = $s.Username
                $Password = $s.Password
                $SessionId = $s.SessionId
                $Proxy = $s.Proxy
            }

            Write-Verbose -Message "Connecting to web service."
            
            if(!$ConnectionUri.EndsWith(".asmx")) {
                $ConnectionUri = "$($ConnectionUri.TrimEnd('/'))/sitecore%20modules/PowerShell/Services/RemoteAutomation.asmx"
            }

            if(!$Proxy) {
                $proxyProps = @{
                    Uri = $ConnectionUri
                }

                if($Credential) {
                    $proxyProps["Credential"] = $Credential
                }

                $proxy = New-WebServiceProxy @proxyProps
                if($Credential) {
                    $proxy.Credentials = $Credential
                }
            }
            if(-not $proxy) { return $null }

            $output = $Destination
            $extension = [System.IO.Path]::GetExtension($Path)
            if(!$output.EndsWith($extension)) {
                if(!$output.EndsWith("/") -and !$output.EndsWith("\")) {
                    $output += "/"
                }

                $output += [System.IO.Path]::GetFileName($Path)
            }
	
            Write-Verbose -Message "Reading file content."
            [byte[]]$bytes = [System.IO.File]::ReadAllBytes($Path)

            if($bytes -and $bytes.Length -gt 0) {

                Write-Verbose -Message "Uploading file content."
                $proxy.UploadFile($Username, $Password, $output, $bytes, $Database, $Language) | Out-Null

                Write-Verbose -Message "Upload complete."
            } else {
                Write-Verbose -Message "Upload failed. No content to send to the web service."
            }
        }
    }
}

Set-Alias -Name "Upload-SitecoreFile" -Value "Send-MediaItem" -Description "SPE"